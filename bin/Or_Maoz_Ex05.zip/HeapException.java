
public class HeapException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public HeapException() {
		super();
	}

	public HeapException(String msg) {
		super(msg);
	}
	
	

}
